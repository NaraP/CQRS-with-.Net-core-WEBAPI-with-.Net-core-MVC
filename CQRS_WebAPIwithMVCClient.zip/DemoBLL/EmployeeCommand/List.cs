﻿using DemoModels;
using DemoRepository.EmployeeRepository;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DemoBLL.EmployeeCommand
{
    /// <summary>
    /// List this class is used fetch the list of employees
    /// </summary>
    public class List
    {
        /// <summary>
        /// Query constructor
        /// </summary>
        public class Query : IRequest<List<EmployeeModel>>
        {
        }

        /// <summary>
        /// QueryHandler MediatR used fetch the list of employees
        /// </summary>
        public class QueryHandler : IAsyncRequestHandler<Query, List<EmployeeModel>>
        {
            private readonly IEmployeeRepository _employeeRepository;

            /// <summary>
            /// QueryHandler
            /// </summary>
            /// <param name="employeeRepository"></param>
            public QueryHandler(IEmployeeRepository employeeRepository)
            {
                _employeeRepository = employeeRepository;
                if (_employeeRepository == null) throw new ArgumentNullException(nameof(_employeeRepository));
            }

            /// <summary>
            /// Handle this method is used to read data from the database
            /// </summary>
            /// <param name="message"></param>
            /// <returns></returns>
            public async Task<List<EmployeeModel>> Handle(Query message)
            {
                List<EmployeeModel> employeesList = new List<EmployeeModel>();

              var empList= await _employeeRepository.GetAllEmployees();

                if(empList!=null && empList.Count>0)
                {
                    foreach(var emp in empList)
                    {
                        EmployeeModel employeeModel = new EmployeeModel();

                        employeeModel.EmpId = emp.EmpId;
                        employeeModel.Name = emp.Name;
                        employeeModel.Address = emp.Address;
                        employeeModel.Gender = emp.Gender;
                        employeeModel.Designation = emp.Designation;
                        employeesList.Add(employeeModel);
                    }
                }
                return employeesList;
            }
        }
    }
}

﻿using DemoModels;
using DemoRepository.EmployeeRepository;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DemoBLL.EmployeeCommand
{
    /// <summary>
    /// Update
    /// </summary>
    public class Update
    {
        /// <summary>
        /// Command
        /// </summary>
        public class Command : IRequest
        {
            public Guid EmpId { get; set; }
            public EmployeeModel Model { get; set; }

            /// <summary>
            /// Command
            /// </summary>
            /// <param name="empId"></param>
            /// <param name="model"></param>
            public Command(Guid empId, EmployeeModel model)
            {
                EmpId = empId;
                Model = model;
            }
        }

        /// <summary>
        /// CommandHandler
        /// </summary>
        public class CommandHandler : IAsyncRequestHandler<Command>
        {
            private readonly IEmployeeRepository _employeeRepository;

            /// <summary>
            /// CommandHandler
            /// </summary>
            /// <param name="employeeRepository"></param>
            public CommandHandler(IEmployeeRepository employeeRepository)
            {
                _employeeRepository = employeeRepository;
                if (_employeeRepository == null) throw new ArgumentNullException(nameof(_employeeRepository));
            }

            /// <summary>
            /// Handle is used to update the employee data based on ht emep id
            /// </summary>
            /// <param name="message"></param>
            /// <returns></returns>
            public async Task Handle(Command message)
            {
                var emp = await _employeeRepository.GetEmployeeById(message.EmpId);
                emp.Name = message.Model.Name;
                emp.Address = message.Model.Address;
                emp.Gender = message.Model.Gender;
                emp.Company = message.Model.Company;
                emp.Designation = message.Model.Designation;

               await _employeeRepository.UpdateEmployee(emp);
            }
        }
    }
}

﻿using DemoModels;
using DemoRepository.EmployeeRepository;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DemoBLL.EmployeeCommand
{
    /// <summary>
    /// EmpDetails
    /// </summary>
    public class EmpDetails
    {
        /// <summary>
        /// DetailsQuery
        /// </summary>
        public class DetailsQuery : IRequest<EmployeeModel>
        {
            public Guid EmpId { get; set; }

            /// <summary>
            /// DetailsQuery
            /// </summary>
            /// <param name="empId"></param>
            public DetailsQuery(Guid empId)
            {
                EmpId = empId;
            }
        }

        /// <summary>
        /// DetailsQueryHandler
        /// </summary>
        public class DetailsQueryHandler : IAsyncRequestHandler<DetailsQuery, EmployeeModel>
        {
            private readonly IEmployeeRepository _employeeRepository;

            /// <summary>
            /// DetailsQueryHandler
            /// </summary>
            /// <param name="employeeRepository"></param>
            public DetailsQueryHandler(IEmployeeRepository employeeRepository)
            {
                _employeeRepository = employeeRepository;
                if (_employeeRepository == null) throw new ArgumentNullException(nameof(_employeeRepository));
            }

            /// <summary>
            /// Handle is used to read the employee data by employee id
            /// </summary>
            /// <param name="message"></param>
            /// <returns></returns>
            public async Task<EmployeeModel> Handle(DetailsQuery message)
            {
                Guid empId = message.EmpId;
                List<EmployeeModel> employeesList = new List<EmployeeModel>();

                var emp = await _employeeRepository.GetEmployeeById(empId);

                EmployeeModel employeeModel = new EmployeeModel();

                if (emp != null)
                {
                    employeeModel.EmpId = emp.EmpId;
                    employeeModel.Name = emp.Name;
                    employeeModel.Address = emp.Address;
                    employeeModel.Gender = emp.Gender;
                    employeeModel.Designation = emp.Designation;
                    employeesList.Add(employeeModel);
                }
                return employeeModel;
            }
        }
    
    }
}

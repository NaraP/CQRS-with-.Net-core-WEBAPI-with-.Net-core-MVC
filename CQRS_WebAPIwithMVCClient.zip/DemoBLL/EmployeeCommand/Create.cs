﻿using DemoCommon.Models;
using DemoModels;
using DemoRepository.EmployeeRepository;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DemoBLL.EmployeeCommand
{
    /// <summary>
    /// Create
    /// </summary>
    public class Create
    {
        /// <summary>
        /// Command
        /// </summary>
        public class Command : IRequest
        {
            public EmployeeModel Model { get; set; }

            /// <summary>
            /// Command
            /// </summary>
            /// <param name="model"></param>
            public Command(EmployeeModel model)
            {
                Model = model;
            }
        }

        /// <summary>
        /// CommandHandler
        /// </summary>
        public class CommandHandler : IAsyncRequestHandler<Command>
        {
            private readonly IEmployeeRepository _employeeRepository;

            /// <summary>
            /// CommandHandler
            /// </summary>
            /// <param name="employeeRepository"></param>
            public CommandHandler(IEmployeeRepository employeeRepository)
            {
                _employeeRepository = employeeRepository;
                if (_employeeRepository == null) throw new ArgumentNullException(nameof(employeeRepository));
            }

            /// <summary>
            /// Handle is used to insert/create new employee record
            /// </summary>
            /// <param name="message"></param>
            /// <returns></returns>
            public async Task Handle(Command message)
            {
                var employee = message.Model;
                await _employeeRepository.CreateEmployee(employee);
            }
        }
    }
}

﻿using DemoRepository.EmployeeRepository;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DemoBLL.EmployeeCommand
{
    /// <summary>
    /// Delete
    /// </summary>
    public class Delete
    {
        /// <summary>
        /// Command
        /// </summary>
        public class Command : IRequest
        {
            public Guid EmpId { get; set; }

            /// <summary>
            /// Command
            /// </summary>
            /// <param name="empId"></param>
            public Command( Guid empId)
            {
                EmpId = empId;
            }
        }

        /// <summary>
        /// CommandHandler
        /// </summary>
        public class CommandHandler : IAsyncRequestHandler<Command>
        {
            private readonly IEmployeeRepository _employeeRepository;

            /// <summary>
            /// CommandHandler
            /// </summary>
            /// <param name="employeeRepository"></param>
            public CommandHandler(IEmployeeRepository employeeRepository)
            {
                _employeeRepository = employeeRepository;
                if (_employeeRepository == null) throw new ArgumentNullException(nameof(employeeRepository));
            }
            /// <summary>
            /// Handle is used to delete/renove the data from the database
            /// </summary>
            /// <param name="message"></param>
            /// <returns></returns>

            public async Task Handle(Command message)
            {
                await _employeeRepository.DeleteEmployeeById(message.EmpId);
            }
        }
    }
}

﻿using DemoCommon.Models;
using DemoModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoRepository.EmployeeRepository
{
   public interface IEmployeeRepository
    {
        Task<Employees> GetEmployeeById(Guid empId);
        Task<Employees> GetEmployeeByName(Guid empId);
        Task<List<Employees>> GetAllEmployees();
        Task<int> CreateEmployee(EmployeeModel employees);
        Task<int> UpdateEmployee(Employees employees);
        Task<int> DeleteEmployeeById(Guid empId);
    }
}

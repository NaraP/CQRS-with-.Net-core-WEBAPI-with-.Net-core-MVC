﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DemoCommon.Helper;
using DemoCommon.Models;
using DemoModels;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace DemoRepository.EmployeeRepository
{
    /// <summary>
    /// EmployeeRepository
    /// </summary>
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly TestDemoContext _testDemoContext;
        private readonly IHttpContextAccessor _httpContextAccessor;

        /// <summary>
        /// EmployeeRepository
        /// </summary>
        /// <param name="testDemoContext"></param>
        /// <param name="httpContextAccessor"></param>
        public EmployeeRepository(TestDemoContext testDemoContext)
        {
            _testDemoContext = testDemoContext;
        }

        /// <summary>
        /// CreateEmployee this method is used to create new employee
        /// </summary>
        /// <param name="employees"></param>
        /// <returns></returns>
        public async Task<int> CreateEmployee(EmployeeModel employees)
        {
            //AddAuditTrial(employees, true);

            var emp = new Employees();
            emp.EmpId = Guid.NewGuid();
            emp.Name = employees.Name;
            emp.Address = employees.Address;
            emp.Gender = employees.Gender;
            emp.Designation = employees.Designation;
            emp.IsActive = true;

            _testDemoContext.Employees.Add(emp);
           /// _testDemoContext.Entry(emp).CurrentValues.SetValues(emp);
            return await _testDemoContext.SaveChangesAsync();
        }

        /// <summary>
        /// AddAuditTrial
        /// </summary>
        /// <param name="employees"></param>
        /// <param name="createOperation"></param>
        private void AddAuditTrial(Employees employees, bool createOperation = false)
        {
            Guid userId = CommonHelper.GetLoggedInUser(_httpContextAccessor).UserId;

            if (createOperation)
            {
                employees.CreateTs = DateTime.UtcNow;
                employees.CreateUser = userId;
            }
            else
            {
                employees.UpdateTs = DateTime.UtcNow;
                employees.UpdateUser = userId;
            }
        }

        /// <summary>
        /// DeleteEmployeeById this  method is used to delete/update flag to false
        /// </summary>
        /// <param name="empId"></param>
        /// <returns></returns>
        public async Task<int> DeleteEmployeeById(Guid empId)
        {
            var employee = await _testDemoContext.Employees.Where(s => empId.Equals(empId)).ToListAsync().ConfigureAwait(false);

            //employee.ForEach(s =>
            //{
            //    s.IsActive = false;
            //    s.UpdateTs = DateTime.UtcNow;
            //  //  s.UpdateUser = CommonHelper.GetCurrentUser(_httpContextAccessor);
            //});

            _testDemoContext.Employees.RemoveRange(employee);
            return await _testDemoContext.SaveChangesAsync().ConfigureAwait(false);
        }

        /// <summary>
        /// GetAllEmployees this method is used to read all records from the database
        /// </summary>
        /// <param name="includeDetails"></param>
        /// <returns></returns>

        public async Task<List<Employees>> GetAllEmployees()
        {
            var employees = await _testDemoContext.Employees
                                      .Where(s => s.IsActive == null || (s.IsActive.HasValue && s.IsActive.Value))
                                      .ToListAsync().ConfigureAwait(false);
            return employees;
        }

        /// <summary>
        /// GetEmployeeById this method is used to read the data by emmployee id from the database
        /// </summary>
        /// <param name="empId"></param>
        /// <param name="includeDetails"></param>
        /// <returns></returns>
        public async Task<Employees> GetEmployeeById(Guid empId)
        {
            var employees = await _testDemoContext.Employees.
                SingleOrDefaultAsync(s => s.EmpId.Equals(empId) && (s.IsActive == null || (s.IsActive.HasValue && s.IsActive.Value))).ConfigureAwait(false);
            return employees;
        }

        /// <summary>
        /// GetEmployeeByName this method is used to read the data by employee name
        /// </summary>
        /// <param name="name"></param>
        /// <param name="empId"></param>
        /// <returns></returns>

        public async Task<Employees> GetEmployeeByName(Guid empId)
        {
            var employees = await _testDemoContext.Employees.SingleOrDefaultAsync(s => s.EmpId.Equals(empId) && (s.IsActive == null || (s.IsActive.HasValue && s.IsActive.Value))).ConfigureAwait(false);
            return employees;
        }

        /// <summary>
        /// UpdateEmployee  this method is used to update the employees data
        /// </summary>
        /// <param name="employees"></param>
        /// <returns></returns>
        public async Task<int> UpdateEmployee(Employees employees)
        {
           // AddAuditTrial(employees);

            _testDemoContext.Employees.Update(employees);

            return await _testDemoContext.SaveChangesAsync().ConfigureAwait(false);
        }
    }
}

﻿using DemoCommon.Dto;
using DemoCommon.IServices;
using DemoCommon.Services;
using DemoRepository.EmployeeRepository;
using DemoWEBAPI.Commands;
using DemoWEBAPI.Queries;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static DemoBLL.EmployeeCommand.Create;
using static DemoBLL.EmployeeCommand.List;

namespace DemoWEBAPI
{
    public static class RegisterServices
    {
        /// <summary>
        /// RegisterChainOfConfigServices this is used for the registrations of the all services and repositories
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configuration"></param>
        public static void RegisterConfigServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<IQueriesService, QueriesService>();
            services.AddScoped<ICommandService, CommandService>();

            services.AddScoped<IEmployeeRepository, EmployeeRepository>();

            services.AddMediatR(typeof(CommandHandler));
            services.AddMediatR(typeof(QueryHandler));



            #region --JWT--
            services.Configure<BearerTokensOptions>(options => configuration.GetSection("BearerTokens").Bind(options));
            services.AddScoped<IUserAuthService, UserAuthService>();
            services.AddSingleton<ISecurityService, SecurityService>();
            services.AddScoped<ITokenStoreService, TokenStoreService>();
            services.AddScoped<ITokenValidatorService, TokenValidatorService>();
            services.AddScoped<IGlobalExceptionLogging, GlobalExceptionLogging>();
            services.AddScoped<IAntiForgeryCookieService, AntiForgeryCookieService>();
            #endregion
        }
    }
}

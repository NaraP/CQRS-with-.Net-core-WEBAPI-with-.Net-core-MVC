﻿using DemoCommon.Models;
using DemoWEBAPI.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoWEBAPI.Mapper
{
    public static class SkillMapper
    {
        public static Skill MapSkillDtoToSkill(this SkillModel skillDto, Skill skill = null)
        {
            Skill retunSkill = new Skill
            {
                SkillId = Guid.NewGuid(),
                SkillName = skillDto.SkillName,
                IsActive = true,
                IsDefaultSkill = false
            };
            return retunSkill;
        }

        public static SkillModel MapSkillToSkillDto(this Skill skill)
        {
            return new SkillModel
            {
                SkillId = skill.SkillId,
                SkillName = skill.SkillName
            };
        }

        public static List<SkillModel> MapSkillToSkillDto( IList<Skill> skill)
        {
            var skillDtos = new List<SkillModel>();

            foreach (var skills in skill)
            {
                var skillDto = skills.MapSkillToSkillDto();
                skillDtos.Add(skillDto);
            }

            return skillDtos;

        }

        public static Skill MapSkillDtosToUpdateSkill(this SkillModel skillDto, Skill skill = null)
        {
            skill.SkillName = skillDto.SkillName;
            skill.IsDefaultSkill = false; //skillDto.IsDefaultSkill;
            return skill;
        }
    }
}

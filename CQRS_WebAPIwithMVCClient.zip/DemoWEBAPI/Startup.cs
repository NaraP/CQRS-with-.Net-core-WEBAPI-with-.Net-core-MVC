﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DemoCommon;
using DemoCommon.Dto;
using DemoCommon.Exceptions;
using DemoCommon.Filters;
using DemoCommon.Helper;
using DemoCommon.Models;
using DemoWEBAPI.Helper;
using DemoWEBAPI.Swagger;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Swashbuckle.AspNetCore.Swagger;

namespace DemoWEBAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            var connectionString = Configuration.GetConnectionString("PostGreSqlConnection");
            services.Configure<BearerTokensOptions>(options => Configuration.GetSection("BearerTokens").Bind(options));
            services.AddSingleton<IConfiguration>(Configuration);

            services.AddDbContext<TestDemoContext>(options => options.UseNpgsql(connectionString));

            services.AddSession(options => {
                options.IdleTimeout = TimeSpan.FromMinutes(1);
            });

            //Registering the all services 
            services.RegisterConfigServices(Configuration);

            //JWT authentication configurations
            services.RegisterChainOfConfigServices(Configuration);

            services.ConfigureJwtAuthenticationService(Configuration);

            services.AddAuthorization(options =>
            {
                // Build an intermediate service provider
                var sp = services.BuildServiceProvider();
                var context = sp.GetService<TestDemoContext>();

                var roles = context.Role.Include(s => s.RolePrivilegeSecurable).ThenInclude(y => y.Privilege)
                                         .Include(s => s.RolePrivilegeSecurable).ThenInclude(y => y.Securable)
                                         .ToList()
                                         .Where(s => s.IsActive == null || (s.IsActive.HasValue && s.IsActive == true));

                foreach (var role in roles)
                {
                    foreach (var priviledge in role.RolePrivilegeSecurable)
                    {
                        options.AddPolicy(priviledge.Securable.SecurableDesc.ToString() + priviledge.Privilege.PrivilegeName.ToString(),
                           policy => policy.RequireClaim(priviledge.Securable.SecurableDesc.ToString() + priviledge.Privilege.PrivilegeName.ToString()));

                        if (priviledge.Privilege.PrivilegeName.Equals(PermissionUserRoles.Edit))
                        {
                            options.AddPolicy(priviledge.Securable.SecurableDesc.ToString() + PermissionUserRoles.View.ToString(),
                           policy => policy.RequireClaim(priviledge.Securable.SecurableDesc.ToString() + PermissionUserRoles.View.ToString()));
                        }
                    }
                }
            });

            // services.AddSwaggerConfigurationSetting(Configuration);
            services.AddSwaggerDocumentation();

            services.AddSingleton<Microsoft.AspNetCore.Http.IHttpContextAccessor, Microsoft.AspNetCore.Http.HttpContextAccessor>();

            services.AddAntiforgery(options => options.HeaderName = "X-XSRF-TOKEN");

            services.AddMvc(config =>
            {
                config.Filters.Add(typeof(DemoExceptionFilter));
                config.Filters.Add(typeof(ValidateModelAttribute));
                config.CacheProfiles.Add("Default", new CacheProfile() { NoStore = true });
            }).SetCompatibilityVersion(Microsoft.AspNetCore.Mvc.CompatibilityVersion.Version_2_2);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }
            //app.UseSwaggerMiddleWare();

            // app.UseSwagger();
            app.UseSwaggerDocumentation();

            //Addd User session - 
            app.UseSession();

            //Add JWToken to all incoming HTTP Request Header - 
            app.Use(async (context, next) =>
            {
                var JWToken = context.Session.GetString("JWToken");
                if (!string.IsNullOrEmpty(JWToken))
                {
                    context.Request.Headers.Add("Authorization", "Bearer " + JWToken);
                }
                await next();
            });

            app.UseHttpsRedirection();

            app.UseHttpsRedirection();
            app.UseAuthentication();
            app.UseCors(builder => builder.AllowAnyOrigin()
                           .AllowAnyMethod()
                           .AllowAnyHeader());

            app.UseAntiforgeryTokens();

            app.UseMvc();
        }
    }
}

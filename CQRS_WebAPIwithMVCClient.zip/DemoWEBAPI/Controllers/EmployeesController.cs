﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using DemoCommon.Helper;
using DemoCommon.Models;
using DemoWEBAPI.Commands;
using DemoWEBAPI.Queries;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace DemoWEBAPI.Controllers
{
    //[Route("api/[controller]")]
   // [ApiController]
    public class EmployeesController : ControllerBase
    {

        private readonly IQueriesService _queries;
        private readonly ICommandService _commands;

        public EmployeesController(IQueriesService queries, ICommandService commands)
        {
            _queries = queries ?? throw new ArgumentNullException(nameof(queries));
            _commands = commands ?? throw new ArgumentNullException(nameof(commands));
        }

        [HttpGet]
        [Route("api/Employees/Get")]
        public async Task<IEnumerable<Employees>> Get()
        {
            return await _queries.GetEmployees();
        }

        [HttpPost]
        [Route("api/Employees/Create")]
        public async Task CreateAsync([FromBody]Employees employee)
        {
            if (ModelState.IsValid)
            {
                await _commands.Add(employee);
            }
        }

        [HttpGet]
        [Route("api/Employees/Details/{id}")]
        public async Task<Employees> Details(string id)
        {
            var result = await _queries.GetEmployee(id);
            return result;
        }

        [HttpPut]
        [Route("api/Employees/Edit")]
        public async Task EditAsync([FromBody]Employees employee)
        {
            if (ModelState.IsValid)
            {
                await _commands.Update(employee);
            }
        }

        [HttpDelete]
        [Route("api/Employees/Delete/{id}")]
        public async Task DeleteConfirmedAsync(string id)
        {
            await _commands.Delete(id);
        }
    }
}
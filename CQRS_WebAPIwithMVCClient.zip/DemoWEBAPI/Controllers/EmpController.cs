﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using DemoModels;

namespace DemoWEBAPI.Controllers
{
    /// <summary>
    /// EmpController
    /// </summary>
    [ApiController]
    public class EmpController : ControllerBase
    {
        private readonly IMediator _mediator;

        /// <summary>
        /// EmpController
        /// </summary>
        /// <param name="mediator"></param>
        public EmpController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// GetEmployeesList this method is used to read the all employees data from the data base
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/Emp/GetEmployeesList")]
        public async Task<IEnumerable<EmployeeModel>> GetEmployeesList()
        {
            var result = await _mediator.Send(new DemoBLL.EmployeeCommand.List.Query());
            return result;
        }

        /// <summary>
        /// CreateEmployee this method is used to create new employee record in the database table
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/Emp/CreateEmployee")]
        public async Task<IActionResult> CreateEmployee([FromBody]EmployeeModel model)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);
           await _mediator.Send(new DemoBLL.EmployeeCommand.Create.Command(model));

            var result = await _mediator.Send(new DemoBLL.EmployeeCommand.List.Query());

            var empResult = result.Where(emp => emp.EmpId.Equals(model.EmpId)).FirstOrDefault();

            HttpStatusCode statusCode = HttpStatusCode.Created;

            return Created(statusCode.ToString(), empResult);
        }

        /// <summary>
        /// DeletEmployee this method is used to delete the employee record from the databaseS
        /// </summary>
        /// <param name="empId"></param>
        /// <returns></returns>
        [HttpDelete]
        [Route("api/Emp/DeleteEmployee")]
        public async Task<IActionResult> DeleteEmployee(Guid empId)
        {
            await _mediator.Send(new DemoBLL.EmployeeCommand.Delete.Command(empId));
            return Ok(HttpStatusCode.OK);
        }

        [HttpGet]
        [Route("api/Emp/EmployeeDetails")]
        public async Task<EmployeeModel> EmployeeDetails(Guid empId)
        {
            var result = await _mediator.Send(new DemoBLL.EmployeeCommand.EmpDetails.DetailsQuery(empId));
            return result; 
        }

        /// <summary>
        /// UpdateEmployee this method is used to delete the employee record from the database
        /// </summary>
        /// <param name="EmpId"></param>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("api/Emp/UpdateEmployee")]
        public async Task<IActionResult> UpdateEmployee(Guid EmpId, [FromBody]EmployeeModel model)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            await _mediator.Send(new DemoBLL.EmployeeCommand.Update.Command(EmpId, model));
            var result = await _mediator.Send(new DemoBLL.EmployeeCommand.List.Query());

            var empResult = result.Where(emp => emp.EmpId.Equals(model.EmpId)).FirstOrDefault();

            return Ok(empResult);
        }

    }
}
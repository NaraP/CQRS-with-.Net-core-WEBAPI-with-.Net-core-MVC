﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DemoCommon.Models;
using DemoWEBAPI.Queries;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using DemoWEBAPI.Commands;
using DemoCommon.Helper;
using Microsoft.AspNetCore.Authorization;

namespace DemoWEBAPI.Controllers
{
    [Route("DemoWEBAPI/Common")]
    [ApiController]
    public class EmployeesSwaggerController : ControllerBase
    {

        private readonly IQueriesService _queries;
        private readonly ICommandService _commands;

        public EmployeesSwaggerController(IQueriesService queries, ICommandService commands)
        {
            _queries = queries ?? throw new ArgumentNullException(nameof(queries));
            _commands = commands ?? throw new ArgumentNullException(nameof(commands));
        }

        [HttpGet("Get", Name = nameof(Get))]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [Authorize(PermissionUserRoles.SkillsView)]
        public async Task<IEnumerable<Employees>> Get()
        {
            return await _queries.GetEmployees();
        }

        [HttpPost("CreateAsync", Name = nameof(CreateAsync))]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(409)]
        [Authorize(PermissionUserRoles.SkillsEdit)]
        public async Task CreateAsync([FromBody]Employees employee)
        {
            if (ModelState.IsValid)
            {
                await _commands.Add(employee);
            }
        }

        [HttpGet("Details", Name = nameof(Details))]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(409)]
        [Authorize(PermissionUserRoles.SkillsEdit)]
        public async Task<Employees> Details(string id)
        {
            var result = await _queries.GetEmployee(id);
            return result;
        }

        [HttpPut("EditAsync", Name = nameof(EditAsync))]
        [ProducesResponseType(204)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [Authorize(PermissionUserRoles.SkillsEdit)]
        public async Task EditAsync([FromBody]Employees employee)
        {
            if (ModelState.IsValid)
            {
                await _commands.Update(employee);
            }
        }

        [HttpDelete("DeleteConfirmedAsync", Name = nameof(DeleteConfirmedAsync))]
        [ProducesResponseType(204)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [Authorize(PermissionUserRoles.SkillsEdit)]
        public async Task DeleteConfirmedAsync(string id)
        {
            await _commands.Delete(id);
        }
    }
}
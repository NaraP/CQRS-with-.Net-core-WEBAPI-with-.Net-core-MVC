﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DemoCommon.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace DemoWEBAPI.Commands
{
    public class CommandService : ICommandService
    {

        private readonly TestDemoContext _testDemoContext;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public CommandService(TestDemoContext testDemoContext, IHttpContextAccessor httpContextAccessor)
        {
            _testDemoContext = testDemoContext;
            _httpContextAccessor = httpContextAccessor;
        }
        public async Task Add(Employees employee)
        {
            employee.EmpId = Guid.NewGuid();
            _testDemoContext.Employees.Add(employee);
            try
            {
                await _testDemoContext.SaveChangesAsync();
            }
            catch (Exception)
            {
            }
        }

        public async Task Update(Employees employee)
        {
            try
            {
                _testDemoContext.Entry(employee).State = EntityState.Modified;
                await _testDemoContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public async Task Delete(string id)
        {
            try
            {
                Employees employee = await _testDemoContext.Employees.FindAsync(id);
                _testDemoContext.Employees.Remove(employee);
                await _testDemoContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}

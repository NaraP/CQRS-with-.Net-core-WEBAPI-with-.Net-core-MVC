﻿using DemoCommon.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoWEBAPI.Commands
{
    public interface ICommandService
    {
        Task Add(Employees employee);
        Task Update(Employees employee);
        Task Delete(string id);
    }
}

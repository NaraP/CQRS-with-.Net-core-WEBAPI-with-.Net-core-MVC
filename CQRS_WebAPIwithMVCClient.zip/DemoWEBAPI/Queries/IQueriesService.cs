﻿using DemoCommon.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoWEBAPI.Queries
{
    public interface IQueriesService
    {
        Task<Employees> GetEmployee(string id);
        Task<IEnumerable<Employees>> GetEmployees();
    }
}

﻿using DemoCommon.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoWEBAPI.Queries
{
    public class QueriesService : IQueriesService
    {
        private readonly TestDemoContext _testDemoContext;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public QueriesService(TestDemoContext testDemoContext, IHttpContextAccessor httpContextAccessor)
        {
            _testDemoContext = testDemoContext;
            _httpContextAccessor = httpContextAccessor;
        }
        public async Task<Employees> GetEmployee(string id)
        {
            try
            {
                Employees employee = await _testDemoContext.Employees.FindAsync(id);
                if (employee == null)
                {
                    return null;
                }
                return employee;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public async Task<IEnumerable<Employees>> GetEmployees()
        {
            try
            {
                var employees = await _testDemoContext.Employees.ToListAsync();
                return employees.AsQueryable();
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}

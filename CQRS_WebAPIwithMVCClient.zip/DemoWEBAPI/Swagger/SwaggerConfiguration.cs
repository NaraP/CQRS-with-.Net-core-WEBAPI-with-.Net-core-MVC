﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Swashbuckle.AspNetCore.Swagger;
using System.Collections.Generic;

namespace DemoWEBAPI.Swagger
{
    /// <summary>
    /// SwaggerConfiguration
    /// </summary>
    public static class SwaggerConfiguration
    {
        /// <summary>
        /// AddSwaggerConfigurationSetting
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configuration"></param>
        public static void AddSwaggerConfigurationSetting(this IServiceCollection services, IConfiguration configuration)
        {
            //swagger
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info
                {
                    Version = "v1",
                    Title = "SwaggerSettings:Title",
                    Description = "SwaggerSettings:Description",
                    TermsOfService = "SwaggerSettings:TermsOfService",
                    Contact = new Contact() { Name = "Demo project", Email = "demoapp@gmail.com", Url = "http://www.demo.com" }
                });

                //Tell swagger to use XML comments.
                c.IncludeXmlComments(Utilities.GetXmlCommentsPath());

                //To add JWT authentication in swagger
                var security = new Dictionary<string, IEnumerable<string>>
                {
                    {"Bearer", new string[] { }},
                };

                c.AddSecurityDefinition("Bearer", new ApiKeyScheme
                {
                    Description = "JWT Authorization header using the Bearer scheme. Example: \"Authorization: Bearer {token}\"",
                    Name = "Authorization",
                    In = "header",
                    Type = "apiKey"
                });
                c.AddSecurityRequirement(security);
            });
        }
    }
}

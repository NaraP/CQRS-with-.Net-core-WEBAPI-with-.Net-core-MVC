﻿using DemoCommon.Models;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using DemoRepository;
using DemoMVC.Controllers;
using DemoRepository.EmployeeRepository;
using DemoMVC.Queries;
using DemoMVC.Commands;

namespace DemoUnitWEBAPI
{
  public  class EmployeeTestController
    {
        EmployeesController _controller;
        IEmployeeRepository _service;

        private readonly IQueriesService _queries;
        private readonly ICommandService _commands;

        public EmployeeTestController()
        {
            _controller = new EmployeesController(_queries, _commands);
        }

        [Fact]
        public void GetDataReturnsOkResult()
        {
            var mock = new Mock<IQueriesService>();
            mock.Setup(p => p.GetEmployee(Guid.Parse("f55c9ef3-c8b8-4e8f-846a-d96eacb2a987")));
            EmployeesController emp = new EmployeesController(mock.Object,null);
            var result = emp.Index();
            Assert.Equal("ABC", result.Result.ToString());
        }

        [Fact]
        public void Get_ReturnsAllItems()
        {
            var mock = new Mock<IQueriesService>();
            mock.Setup(p => p.GetEmployees());
            EmployeesController emp = new EmployeesController(mock.Object, null);
            var result = emp.Index();
            Assert.Equal("ABC", result.Result.ToString());
        }
        [Fact]
        public void Get_ReturnsDelete()
        {
            var mock = new Mock<ICommandService>();
            mock.Setup(p => p.Delete(Guid.Parse("f55c9ef3-c8b8-4e8f-846a-d96eacb2a987")));
            EmployeesController home = new EmployeesController(null, mock.Object);
            var result = home.Delete(Guid.Parse("f55c9ef3-c8b8-4e8f-846a-d96eacb2a987"));
            Assert.Equal("ABC",result.ToString());
        }

        [Fact]
        public void Get_ReturnsCreate()
        {
            Employees employees = new Employees();
            employees.EmpId = Guid.NewGuid();
            employees.Name = "ABB";
            employees.Gender = "M";
            employees.Designation = "OT";

            var mock = new Mock<ICommandService>();

            mock.Setup(p => p.Add(employees));
            EmployeesController home = new EmployeesController(null, mock.Object);
            var result = home.Create(employees);
            Assert.Equal("ABC", result.ToString());
        }

        [Fact]
        public void Get_ReturnsUpdate()
        {
            Employees employees = new Employees();
            employees.EmpId = Guid.NewGuid();
            employees.Name = "ABC";
            employees.Gender = "M";
            employees.Designation = "OT";

            var mock = new Mock<ICommandService>();

            mock.Setup(p => p.Add(employees));
            EmployeesController home = new EmployeesController(null, mock.Object);
            var result = home.Edit(employees);
            Assert.Equal("ABC", result.ToString());
        }

    }
}

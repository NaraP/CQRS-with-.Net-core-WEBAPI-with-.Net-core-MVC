﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DemoCommon.Dto;
using DemoCommon.IServices;
using JwtMvcCoreCrud.Dto;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace JwtMvcCoreCrud.Controllers
{
    public class LoginController : Controller
    {
        private readonly IUserAuthService _usersService;
        private readonly ITokenStoreService _tokenStoreService;
        private readonly IAntiForgeryCookieService _antiforgery;
        private readonly ILogger _loginLogger;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IConfiguration _configuration;

        public LoginController(IUserAuthService usersService,
                         ITokenStoreService tokenStoreService, ILogger<LoginController> logger, IHostingEnvironment hostingEnvironment,
                         IAntiForgeryCookieService antiforgery,
                        IConfiguration configuration)
        {
            _usersService = usersService;
            _tokenStoreService = tokenStoreService;
            _antiforgery = antiforgery;
            _loginLogger = logger;
            _hostingEnvironment = hostingEnvironment;
            _configuration = configuration;
        }
        public async Task<ActionResult> Index()
        {
            return View();
        }

        /// <summary>
        /// Index method is used for the user login
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        public async Task<ActionResult> Index(LoginModel loginModel)
        {
            if (loginModel.UserName != null && loginModel.Password != null)
            {
                UserDto userDto = new UserDto
                {
                    UserName = loginModel.UserName,
                    Password = loginModel.Password
                };

                var user = default(UserDto);

                user = await _usersService.FindUserAsync(userDto);

                var userToken = await _tokenStoreService.CreateJwtTokens(user, refreshTokenSource: null);

                if (userToken != null)
                {
                    //Save token in session object
                    HttpContext.Session.SetString("JWToken", userToken.AccessToken);
                }
                return Redirect("~/Employees/Index");
            }
            return View();
        }


        public async Task<ActionResult> LoginUser(LoginModel loginModel)
        {
            if (loginModel.UserName != null && loginModel.Password != null)
            {

                UserDto userDto = new UserDto
                {
                    UserName = loginModel.UserName,
                    Password = loginModel.Password
                };

                var user = default(UserDto);

                user = await _usersService.FindUserAsync(userDto);

                var userToken = await _tokenStoreService.CreateJwtTokens(user, refreshTokenSource: null);

                if (userToken != null)
                {
                    //Save token in session object
                    HttpContext.Session.SetString("JWToken", userToken.AccessToken);
                }
                return Redirect("~/Employees/Index");
            }
            return null;
        }
    }
}
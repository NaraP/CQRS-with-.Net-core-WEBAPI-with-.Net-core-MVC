﻿using DemoCommon.Dto;
using DemoCommon.IServices;
using DemoCommon.Services;
using JwtMvcCoreCrud.Repository;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JwtMvcCoreCrud
{
    public static class RegisterServices
    {
        public static void RegisterConfigServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<IEmployeeRepository, EmployeeRepository>();
            // services.AddScoped<IEmployeeService, EmployeeService>();

            #region --JWT--
            services.Configure<BearerTokensOptions>(options => configuration.GetSection("BearerTokens").Bind(options));
            services.AddScoped<IUserAuthService, UserAuthService>();
            services.AddSingleton<ISecurityService, SecurityService>();
            services.AddScoped<ITokenStoreService, TokenStoreService>();
            services.AddScoped<ITokenValidatorService, TokenValidatorService>();
            services.AddScoped<IGlobalExceptionLogging, GlobalExceptionLogging>();
            services.AddScoped<IAntiForgeryCookieService, AntiForgeryCookieService>();
            #endregion
        }

    }
}

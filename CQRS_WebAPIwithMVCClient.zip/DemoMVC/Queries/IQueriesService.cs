﻿using DemoCommon.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace DemoMVC.Queries
{
    public interface IQueriesService
    {
        Task<HttpResponseMessage> GetEmployee(Guid EmpID);
        Task<HttpResponseMessage> GetEmployees();
    }
}

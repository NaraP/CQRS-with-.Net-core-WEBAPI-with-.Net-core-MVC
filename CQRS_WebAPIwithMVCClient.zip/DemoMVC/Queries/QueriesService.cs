﻿using DemoCommon.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace DemoMVC.Queries
{
    public class QueriesService : IQueriesService
    {
        // this line code is used to read the web api url from the appsettings file
        IConfigurationRoot configHelper = ConfigHelper.GetConnectionSection();

        /// <summary>
        /// GetEmployee this method is used to read the employee record by employee Id
        /// </summary>
        /// <param name="EmpID"></param>
        /// <returns></returns>
        public async Task<HttpResponseMessage> GetEmployee(Guid EmpID)
        {
            HttpResponseMessage httpResponseMessage = new HttpResponseMessage();

            using (var client = new HttpClient())
            {
                var baseUrl = configHelper["apiBaseAddress"];

                client.BaseAddress = new Uri(baseUrl);

                httpResponseMessage = await client.GetAsync("Emp/GetEmployeesList");
            }
            return httpResponseMessage;
        }

        /// <summary>
        /// GetEmployees this method is used to read the all employees records from the  database
        /// </summary>
        /// <returns></returns>
        public async Task<HttpResponseMessage> GetEmployees()
        {
            HttpResponseMessage httpResponseMessage = new HttpResponseMessage();
            
            using (var client = new HttpClient())
            {
                var baseUrl = configHelper["apiBaseAddress"];

                client.BaseAddress = new Uri(baseUrl);

                httpResponseMessage = await client.GetAsync("Emp/GetEmployeesList");
            }
            return httpResponseMessage;
        }
    }
}

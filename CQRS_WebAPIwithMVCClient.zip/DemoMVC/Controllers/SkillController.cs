﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using DemoMVC.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace DemoMVC.Controllers
{


    public class SkillController : Controller
    {
        IConfigurationRoot configHelper = ConfigHelper.GetConnectionSection();

        // GET: Skill
        [HttpGet]
        public async Task<ActionResult> Index()
        {
            var baseUrl = configHelper["apiBaseAddress"];

            IEnumerable<SkillModel> skillModel = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseUrl);

                var result = await client.GetAsync("Skiils/GetAllSkills");

                if (result.IsSuccessStatusCode)
                {
                    skillModel = await result.Content.ReadAsAsync<IList<SkillModel>>();
                }
                else
                {
                    skillModel = new List<SkillModel>();
                    ModelState.AddModelError(string.Empty, "Server error try after some time.");
                }
            }
            return View(skillModel);
        }

        // GET: Skill/Details/5
        [HttpGet]
        public async Task<ActionResult> Details(Guid id)
        {
            if (id == null)
            {
                id = Guid.Parse("46bd574d-3f9e-4a3c-9732-b5d7f4273e1b");
            }
            SkillModel skillModel = null;

            using (var client = new HttpClient())
            {
                var baseUrl = configHelper["apiBaseAddress"];

                client.BaseAddress = new Uri(baseUrl);

                var result = await client.GetAsync($"Skiils/GetSkillByIds/{id}");

                if (result.IsSuccessStatusCode)
                {
                    skillModel = await result.Content.ReadAsAsync<SkillModel>();
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Server error try after some time.");
                }
            }
            if (skillModel == null)
            {
                return null;
            }
            return View(skillModel);
        }

        // GET: Skill/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Skill/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(SkillModel skillModel,IFormCollection collection)
        {
            // if (ModelState.IsValid)
            // {
            using (var client = new HttpClient())
            {
                var baseUrl = configHelper["apiBaseAddress"];

                client.BaseAddress = new Uri(baseUrl);
                skillModel.SkillId = Guid.NewGuid();

                var response = await client.PostAsJsonAsync("Skiils/CreateSkill", skillModel);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Server error try after some time.");
                }
            }
            //}
            return View(skillModel);
        }

        // GET: Skill/Edit/5
        [HttpGet]
        public async Task<ActionResult> Edit(Guid id)
        {
            if (id == null)
            {
                id = Guid.Parse("46bd574d-3f9e-4a3c-9732-b5d7f4273e1b");
            }
            SkillModel skillModel = null;

            using (var client = new HttpClient())
            {
                var baseUrl = configHelper["apiBaseAddress"];

                client.BaseAddress = new Uri(baseUrl);

                var result = await client.GetAsync($"Skiils/GetSkillByIds/{id}");

                if (result.IsSuccessStatusCode)
                {
                    skillModel = await result.Content.ReadAsAsync<SkillModel>();
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Server error try after some time.");
                }
            }
            if (skillModel == null)
            {
                return null;
            }
            return View(skillModel);
        }

        // POST: Skill/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(Guid id, SkillModel skillModel)
        {
                using (var client = new HttpClient())
                {
                    var baseUrl = configHelper["apiBaseAddress"];

                    client.BaseAddress = new Uri(baseUrl);
                    var response = await client.PutAsJsonAsync("Skiils/UpdateSkill", skillModel);
                    if (response.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        ModelState.AddModelError(string.Empty, "Server error try after some time.");
                    }
                }
                return RedirectToAction("Index");
        }

        // GET: Skill/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Skill/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Delete(Guid id, IFormCollection collection)
        {
            using (var client = new HttpClient())
            {
                var baseUrl = configHelper["apiBaseAddress"];

                client.BaseAddress = new Uri(baseUrl);

                var response = await client.DeleteAsync($"Skiils/DeleteSkillByIds/{id}");
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
                else
                    ModelState.AddModelError(string.Empty, "Server error try after some time.");
            }
            return View();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using DemoCommon.Models;
using DemoMVC.Commands;
using DemoMVC.Queries;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace DemoMVC.Controllers
{
    public class EmployeesController : Controller
    {
        private readonly IQueriesService _queries;
        private readonly ICommandService _commands;

        public EmployeesController(IQueriesService queries, ICommandService commands)
        {
            _queries = queries ?? throw new ArgumentNullException(nameof(queries));
            _commands = commands ?? throw new ArgumentNullException(nameof(commands));
        }

        [HttpGet]
        public async Task<ActionResult> Index()
        {
            IEnumerable<Employees> employees = null;

            var result = await _queries.GetEmployees();

            if (result.IsSuccessStatusCode)
            {
                employees = await result.Content.ReadAsAsync<IList<Employees>>();
            }
            else
            {
                employees = Enumerable.Empty<Employees>();

                ModelState.AddModelError(string.Empty, "Server error try after some time.");
            }
            return View(employees);
        }

        public async Task<ActionResult> Details(Guid EmpID)
        {
            if (EmpID == null)
            {
                return null;
            }

            Employees employee = null;

            var result = await _queries.GetEmployee(EmpID);

            if (result.IsSuccessStatusCode)
            {
                employee = await result.Content.ReadAsAsync<Employees>();
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Server error try after some time.");
            }

            if (employee == null)
            {
                // return HttpNotFound();
            }
            return View(employee);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(Employees employee)
        {
            if (ModelState.IsValid)
            {
                var response = await _commands.Add(employee);

                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Server error try after some time.");
                }
            }
            return View(employee);
        }

        [HttpGet]
        public async Task<ActionResult> Edit(Guid EmpID)
        {
            if (EmpID == null)
            {
                return null;
            }

            Employees employee = null;

            var result = await _queries.GetEmployee(EmpID);

            if (result.IsSuccessStatusCode)
            {
                employee = await result.Content.ReadAsAsync<Employees>();
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Server error try after some time.");
            }

            if (employee == null)
            {
                // return HttpNotFound();
            }
            return View(employee);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(Employees employee)
        {
            if (ModelState.IsValid)
            {
                var response = await _commands.Update(employee);

                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Server error try after some time.");
                }
                return RedirectToAction("Index");
            }
            return View(employee);
        }


        [HttpPost]
        public async Task<ActionResult> Delete(Guid EmpId)
        {
            if (EmpId == null)
            {
                // return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employees employee = null;

            var response = await _commands.Delete(EmpId);

            if (response.IsSuccessStatusCode)
            {
                employee = await response.Content.ReadAsAsync<Employees>();
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Server error try after some time.");
            }

            if (employee == null)
            {
                // return HttpNotFound();
            }
            return View(employee);
        }
    }
}
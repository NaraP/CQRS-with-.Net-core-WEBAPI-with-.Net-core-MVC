﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using DemoCommon.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace DemoMVC.Commands
{
    /// <summary>
    /// CommandService
    /// </summary>
    public class CommandService : ICommandService
    {
        // this line code is used to read the web api url from the appsettings file
        IConfigurationRoot configHelper = ConfigHelper.GetConnectionSection();

        /// <summary>
        /// Add this method is used to create new employee record in the database
        /// </summary>
        /// <param name="employee"></param>
        /// <returns></returns>
        public async Task<HttpResponseMessage> Add(Employees employee)
        {
            HttpResponseMessage httpResponseMessage = new HttpResponseMessage();

            using (var client = new HttpClient())
            {
                var baseUrl = configHelper["apiBaseAddress"];

                client.BaseAddress = new Uri(baseUrl);

                httpResponseMessage = await client.PostAsJsonAsync("Emp/CreateEmployee", employee);
            }
            return httpResponseMessage;
        }

        /// <summary>
        /// Update this method is ised to update/modify/edit the existing employee record in the data base table
        /// </summary>
        /// <param name="employee"></param>
        /// <returns></returns>
        public async Task<HttpResponseMessage> Update(Employees employee)
        {
            HttpResponseMessage httpResponseMessage = new HttpResponseMessage();

            using (var client = new HttpClient())
            {
                var baseUrl = configHelper["apiBaseAddress"];

                client.BaseAddress = new Uri(baseUrl);
                httpResponseMessage = await client.PutAsJsonAsync("Emp/UpdateEmployee", employee);
            }
            return httpResponseMessage;
        }

        /// <summary>
        /// Delete this method is used to delete the employee record from the database table
        /// </summary>
        /// <param name="EmpId"></param>
        /// <returns></returns>
        public async Task<HttpResponseMessage> Delete(Guid EmpId)
        {
            HttpResponseMessage httpResponseMessage = new HttpResponseMessage();

            using (var client = new HttpClient())
            {
                var baseUrl = configHelper["apiBaseAddress"];

                client.BaseAddress = new Uri(baseUrl);

                 httpResponseMessage = await client.GetAsync($"Emp/DeleteEmployee/{EmpId}");
            }
            return httpResponseMessage;
        }
    }
}

﻿using DemoCommon.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace DemoMVC.Commands
{
    public interface ICommandService
    {
        Task<HttpResponseMessage> Add(Employees employee);
        Task<HttpResponseMessage> Update(Employees employee);
        Task<HttpResponseMessage> Delete(Guid EmpId);
    }
}

﻿using System;
using System.Collections.Generic;

namespace DemoCommon.Models
{
    public partial class Skill
    {
        public Guid SkillId { get; set; }
        public string SkillName { get; set; }
        public bool? IsDefaultSkill { get; set; }
        public bool? IsActive { get; set; }
        public Guid CreateUser { get; set; }
        public DateTime CreateTs { get; set; }
        public Guid UpdateUser { get; set; }
        public DateTime UpdateTs { get; set; }
    }
}

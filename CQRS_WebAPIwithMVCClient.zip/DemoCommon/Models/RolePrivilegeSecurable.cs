﻿using System;
using System.Collections.Generic;

namespace DemoCommon.Models
{
    public partial class RolePrivilegeSecurable
    {
        public Guid RoleId { get; set; }
        public Guid PrivilegeId { get; set; }
        public Guid SecurableId { get; set; }
        public bool? IsActive { get; set; }
        public Guid CreateUser { get; set; }
        public DateTime CreateTs { get; set; }
        public Guid UpdateUser { get; set; }
        public DateTime UpdateTs { get; set; }

        public virtual Privilege Privilege { get; set; }
        public virtual Role Role { get; set; }
        public virtual Securable Securable { get; set; }
    }
}

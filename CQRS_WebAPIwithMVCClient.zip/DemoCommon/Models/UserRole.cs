﻿using System;
using System.Collections.Generic;

namespace DemoCommon.Models
{
    public partial class UserRole
    {
        public Guid UserId { get; set; }
        public Guid RoleId { get; set; }
        public bool? IsActive { get; set; }
        public Guid CreateUser { get; set; }
        public DateTime CreateTs { get; set; }
        public Guid UpdateUser { get; set; }
        public DateTime UpdateTs { get; set; }

        public virtual Role Role { get; set; }
        public virtual User User { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;

namespace DemoCommon.Models
{
    public partial class SecurableGrp
    {
        public SecurableGrp()
        {
            Securable = new HashSet<Securable>();
        }

        public Guid SecurableGrpId { get; set; }
        public string SecurableGrpName { get; set; }
        public string SecurableGrpDesc { get; set; }
        public bool? IsActive { get; set; }
        public Guid CreateUser { get; set; }
        public DateTime CreateTs { get; set; }
        public Guid UpdateUser { get; set; }
        public DateTime UpdateTs { get; set; }

        public virtual ICollection<Securable> Securable { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;

namespace DemoCommon.Models
{
    public partial class Role
    {
        public Role()
        {
            RolePrivilegeSecurable = new HashSet<RolePrivilegeSecurable>();
            UserRole = new HashSet<UserRole>();
        }

        public Guid RoleId { get; set; }
        public string RoleName { get; set; }
        public string DisplayRoleName { get; set; }
        public string RoleDesc { get; set; }
        public bool IsSystemRole { get; set; }
        public bool IsDefaultRole { get; set; }
        public bool? IsActive { get; set; }
        public Guid CreateUser { get; set; }
        public DateTime CreateTs { get; set; }
        public Guid UpdateUser { get; set; }
        public DateTime UpdateTs { get; set; }

        public virtual ICollection<RolePrivilegeSecurable> RolePrivilegeSecurable { get; set; }
        public virtual ICollection<UserRole> UserRole { get; set; }
    }
}

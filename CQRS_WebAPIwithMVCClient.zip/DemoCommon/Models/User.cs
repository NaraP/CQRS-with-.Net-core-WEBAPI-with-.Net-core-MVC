﻿using System;
using System.Collections.Generic;

namespace DemoCommon.Models
{
    public partial class User
    {
        public User()
        {
            UserRole = new HashSet<UserRole>();
            UserToken = new HashSet<UserToken>();
        }

        public Guid UserId { get; set; }
        public string UserName { get; set; }
        public string FirstName { get; set; }
        public string SurName { get; set; }
        public string Password { get; set; }
        public string Employer { get; set; }
        public string JobPosition { get; set; }
        public string EmailId { get; set; }
        public string Phone { get; set; }
        public decimal? HourlyRate { get; set; }
        public bool? EnableSkill { get; set; }
        public decimal? PerfRating { get; set; }
        public Guid SerialNumber { get; set; }
        public string SaltHash { get; set; }
        public DateTime LastLoginTs { get; set; }
        public bool? IsActive { get; set; }
        public Guid CreateUser { get; set; }
        public DateTime CreateTs { get; set; }
        public Guid UpdateUser { get; set; }
        public DateTime UpdateTs { get; set; }

        public virtual ICollection<UserRole> UserRole { get; set; }
        public virtual ICollection<UserToken> UserToken { get; set; }
    }
}

﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace DemoCommon.Models
{
    public partial class TestDemoContext : DbContext
    {
        public TestDemoContext()
        {
        }

        public TestDemoContext(DbContextOptions<TestDemoContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Employees> Employees { get; set; }
        public virtual DbSet<ExceptionLog> ExceptionLog { get; set; }
        public virtual DbSet<Privilege> Privilege { get; set; }
        public virtual DbSet<Role> Role { get; set; }
        public virtual DbSet<RolePrivilegeSecurable> RolePrivilegeSecurable { get; set; }
        public virtual DbSet<Securable> Securable { get; set; }
        public virtual DbSet<SecurableGrp> SecurableGrp { get; set; }
        public virtual DbSet<User> User { get; set; }
        public virtual DbSet<UserRole> UserRole { get; set; }
        public virtual DbSet<Skill> Skill { get; set; }

        public virtual DbSet<UserToken> UserToken { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseNpgsql("User ID=abbadmin@abbrcsdatabse;Password=relcare123#;Host=abbrcsdatabse.postgres.database.azure.com;Port=5432;Database=TestDemo;Pooling=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasPostgresExtension("pg_buffercache")
                .HasPostgresExtension("pg_stat_statements")
                .HasPostgresExtension("uuid-ossp")
                .HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

            modelBuilder.Entity<Employees>(entity =>
            {
                entity.HasKey(e => e.EmpId)
                    .HasName("pk_emp");

                entity.ToTable("employees", "demo_app");

                entity.Property(e => e.EmpId)
                    .HasColumnName("emp_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.Address)
                    .HasColumnName("address")
                    .HasMaxLength(50);

                entity.Property(e => e.Company)
                    .HasColumnName("company")
                    .HasMaxLength(50);

                entity.Property(e => e.CreateTs).HasColumnName("create_ts");

                entity.Property(e => e.CreateUser).HasColumnName("create_user");

                entity.Property(e => e.Designation)
                    .HasColumnName("designation")
                    .HasMaxLength(50);

                entity.Property(e => e.Gender)
                    .HasColumnName("gender")
                    .HasMaxLength(50);

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("is_active")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.Name)
                    .HasColumnName("name")
                    .HasMaxLength(50);

                entity.Property(e => e.UpdateTs).HasColumnName("update_ts");

                entity.Property(e => e.UpdateUser).HasColumnName("update_user");
            });

            modelBuilder.Entity<ExceptionLog>(entity =>
            {
                entity.HasKey(e => e.ExceptionId)
                    .HasName("pk_exception_log");

                entity.ToTable("exception_log", "demo_app");

                entity.Property(e => e.ExceptionId)
                    .HasColumnName("exception_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.ActionName)
                    .IsRequired()
                    .HasColumnName("action_name")
                    .HasMaxLength(100);

                entity.Property(e => e.ControllerName)
                    .IsRequired()
                    .HasColumnName("controller_name")
                    .HasMaxLength(100);

                entity.Property(e => e.CreateTs).HasColumnName("create_ts");

                entity.Property(e => e.CreateUser).HasColumnName("create_user");

                entity.Property(e => e.ExceptionMsg)
                    .IsRequired()
                    .HasColumnName("exception_msg")
                    .HasMaxLength(5000);

                entity.Property(e => e.ExceptionSource)
                    .IsRequired()
                    .HasColumnName("exception_source")
                    .HasMaxLength(5000);

                entity.Property(e => e.ExceptionTs).HasColumnName("exception_ts");

                entity.Property(e => e.ExceptionType)
                    .IsRequired()
                    .HasColumnName("exception_type")
                    .HasMaxLength(1000);

                entity.Property(e => e.ExceptionUrl)
                    .IsRequired()
                    .HasColumnName("exception_url")
                    .HasMaxLength(500);

                entity.Property(e => e.RemoteIpAddr)
                    .HasColumnName("remote_ip_addr")
                    .HasMaxLength(500);
            });

            modelBuilder.Entity<Privilege>(entity =>
            {
                entity.ToTable("privilege", "demo_app");

                entity.Property(e => e.PrivilegeId)
                    .HasColumnName("privilege_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.CreateTs).HasColumnName("create_ts");

                entity.Property(e => e.CreateUser).HasColumnName("create_user");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("is_active")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.PrivilegeDesc)
                    .IsRequired()
                    .HasColumnName("privilege_desc")
                    .HasMaxLength(2000);

                entity.Property(e => e.PrivilegeName)
                    .IsRequired()
                    .HasColumnName("privilege_name")
                    .HasMaxLength(50);

                entity.Property(e => e.UpdateTs).HasColumnName("update_ts");

                entity.Property(e => e.UpdateUser).HasColumnName("update_user");
            });

            modelBuilder.Entity<Role>(entity =>
            {
                entity.ToTable("role", "demo_app");

                entity.Property(e => e.RoleId)
                    .HasColumnName("role_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.CreateTs).HasColumnName("create_ts");

                entity.Property(e => e.CreateUser).HasColumnName("create_user");

                entity.Property(e => e.DisplayRoleName)
                    .IsRequired()
                    .HasColumnName("display_role_name")
                    .HasMaxLength(50);

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("is_active")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.IsDefaultRole).HasColumnName("is_default_role");

                entity.Property(e => e.IsSystemRole).HasColumnName("is_system_role");

                entity.Property(e => e.RoleDesc)
                    .IsRequired()
                    .HasColumnName("role_desc")
                    .HasMaxLength(500);

                entity.Property(e => e.RoleName)
                    .IsRequired()
                    .HasColumnName("role_name")
                    .HasMaxLength(50);

                entity.Property(e => e.UpdateTs).HasColumnName("update_ts");

                entity.Property(e => e.UpdateUser).HasColumnName("update_user");
            });

            modelBuilder.Entity<RolePrivilegeSecurable>(entity =>
            {
                entity.HasKey(e => new { e.RoleId, e.PrivilegeId, e.SecurableId })
                    .HasName("pk_role_privilege_securable");

                entity.ToTable("role_privilege_securable", "demo_app");

                entity.Property(e => e.RoleId).HasColumnName("role_id");

                entity.Property(e => e.PrivilegeId).HasColumnName("privilege_id");

                entity.Property(e => e.SecurableId).HasColumnName("securable_id");

                entity.Property(e => e.CreateTs).HasColumnName("create_ts");

                entity.Property(e => e.CreateUser).HasColumnName("create_user");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("is_active")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.UpdateTs).HasColumnName("update_ts");

                entity.Property(e => e.UpdateUser).HasColumnName("update_user");

                entity.HasOne(d => d.Privilege)
                    .WithMany(p => p.RolePrivilegeSecurable)
                    .HasForeignKey(d => d.PrivilegeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("role_privilege_securable_privilege_id_fkey");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.RolePrivilegeSecurable)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("role_privilege_securable_role_id_fkey");

                entity.HasOne(d => d.Securable)
                    .WithMany(p => p.RolePrivilegeSecurable)
                    .HasForeignKey(d => d.SecurableId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("role_privilege_securable_securable_id_fkey");
            });

            modelBuilder.Entity<Securable>(entity =>
            {
                entity.ToTable("securable", "demo_app");

                entity.Property(e => e.SecurableId)
                    .HasColumnName("securable_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.CreateTs).HasColumnName("create_ts");

                entity.Property(e => e.CreateUser).HasColumnName("create_user");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("is_active")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.SecurableDesc)
                    .IsRequired()
                    .HasColumnName("securable_desc")
                    .HasMaxLength(2000);

                entity.Property(e => e.SecurableGrpId).HasColumnName("securable_grp_id");

                entity.Property(e => e.SecurableName)
                    .IsRequired()
                    .HasColumnName("securable_name")
                    .HasMaxLength(50);

                entity.Property(e => e.UpdateTs).HasColumnName("update_ts");

                entity.Property(e => e.UpdateUser).HasColumnName("update_user");

                entity.HasOne(d => d.SecurableGrp)
                    .WithMany(p => p.Securable)
                    .HasForeignKey(d => d.SecurableGrpId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("securable_securable_grp_id_fkey");
            });

            modelBuilder.Entity<SecurableGrp>(entity =>
            {
                entity.ToTable("securable_grp", "demo_app");

                entity.Property(e => e.SecurableGrpId)
                    .HasColumnName("securable_grp_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.CreateTs).HasColumnName("create_ts");

                entity.Property(e => e.CreateUser).HasColumnName("create_user");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("is_active")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.SecurableGrpDesc)
                    .IsRequired()
                    .HasColumnName("securable_grp_desc")
                    .HasMaxLength(2000);

                entity.Property(e => e.SecurableGrpName)
                    .IsRequired()
                    .HasColumnName("securable_grp_name")
                    .HasMaxLength(50);

                entity.Property(e => e.UpdateTs).HasColumnName("update_ts");

                entity.Property(e => e.UpdateUser).HasColumnName("update_user");
            });

            modelBuilder.Entity<Skill>(entity =>
            {
                entity.ToTable("skill", "demo_app");

                entity.Property(e => e.SkillId)
                    .HasColumnName("skill_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.CreateTs).HasColumnName("create_ts");

                entity.Property(e => e.CreateUser).HasColumnName("create_user");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("is_active")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.IsDefaultSkill)
                    .IsRequired()
                    .HasColumnName("is_default_skill")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.SkillName)
                    .IsRequired()
                    .HasColumnName("skill_name")
                    .HasMaxLength(50);

                entity.Property(e => e.UpdateTs).HasColumnName("update_ts");

                entity.Property(e => e.UpdateUser).HasColumnName("update_user");
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.ToTable("user", "demo_app");

                entity.Property(e => e.UserId)
                    .HasColumnName("user_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.CreateTs).HasColumnName("create_ts");

                entity.Property(e => e.CreateUser).HasColumnName("create_user");

                entity.Property(e => e.EmailId)
                    .IsRequired()
                    .HasColumnName("email_id")
                    .HasMaxLength(50);

                entity.Property(e => e.Employer)
                    .IsRequired()
                    .HasColumnName("employer")
                    .HasMaxLength(50);

                entity.Property(e => e.EnableSkill)
                    .HasColumnName("enable_skill")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasColumnName("first_name")
                    .HasMaxLength(50);

                entity.Property(e => e.HourlyRate)
                    .HasColumnName("hourly_rate")
                    .HasColumnType("numeric(10,2)");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("is_active")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.JobPosition)
                    .IsRequired()
                    .HasColumnName("job_position")
                    .HasMaxLength(50);

                entity.Property(e => e.LastLoginTs).HasColumnName("last_login_ts");

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasColumnName("password")
                    .HasMaxLength(50);

                entity.Property(e => e.PerfRating)
                    .HasColumnName("perf_rating")
                    .HasColumnType("numeric(10,2)");

                entity.Property(e => e.Phone)
                    .HasColumnName("phone")
                    .HasMaxLength(20);

                entity.Property(e => e.SaltHash)
                    .IsRequired()
                    .HasColumnName("salt_hash")
                    .HasMaxLength(200);

                entity.Property(e => e.SerialNumber).HasColumnName("serial_number");

                entity.Property(e => e.SurName)
                    .IsRequired()
                    .HasColumnName("sur_name")
                    .HasMaxLength(50);

                entity.Property(e => e.UpdateTs).HasColumnName("update_ts");

                entity.Property(e => e.UpdateUser).HasColumnName("update_user");

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasColumnName("user_name")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<UserRole>(entity =>
            {
                entity.HasKey(e => new { e.UserId, e.RoleId })
                    .HasName("pk_user_role");

                entity.ToTable("user_role", "demo_app");

                entity.Property(e => e.UserId).HasColumnName("user_id");

                entity.Property(e => e.RoleId).HasColumnName("role_id");

                entity.Property(e => e.CreateTs).HasColumnName("create_ts");

                entity.Property(e => e.CreateUser).HasColumnName("create_user");

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasColumnName("is_active")
                    .HasDefaultValueSql("true");

                entity.Property(e => e.UpdateTs).HasColumnName("update_ts");

                entity.Property(e => e.UpdateUser).HasColumnName("update_user");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.UserRole)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("user_role_role_id_fkey");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.UserRole)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("user_role_user_id_fkey");
            });

            modelBuilder.Entity<UserToken>(entity =>
            {
                entity.ToTable("user_token", "demo_app");

                entity.Property(e => e.UserTokenId)
                    .HasColumnName("user_token_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.AccessTokenExpiresTs).HasColumnName("access_token_expires_ts");

                entity.Property(e => e.AccessTokenHash)
                    .HasColumnName("access_token_hash")
                    .HasMaxLength(2000);

                entity.Property(e => e.CreateTs).HasColumnName("create_ts");

                entity.Property(e => e.CreateUser).HasColumnName("create_user");

                entity.Property(e => e.IsActive).HasColumnName("is_active");

                entity.Property(e => e.RefreshTokenExpiresTs).HasColumnName("refresh_token_expires_ts");

                entity.Property(e => e.RefreshTokenIdHash)
                    .HasColumnName("refresh_token_id_hash")
                    .HasMaxLength(1000);

                entity.Property(e => e.RefreshTokenIdHashSource)
                    .HasColumnName("refresh_token_id_hash_source")
                    .HasMaxLength(1000);

                entity.Property(e => e.UpdateTs).HasColumnName("update_ts");

                entity.Property(e => e.UpdateUser).HasColumnName("update_user");

                entity.Property(e => e.UserId).HasColumnName("user_id");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.UserToken)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("user_token_user_id_fkey");
            });
        }
    }
}

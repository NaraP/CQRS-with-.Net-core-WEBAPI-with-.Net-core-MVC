﻿using System;
using System.Collections.Generic;

namespace DemoCommon.Models
{
    public partial class UserToken
    {
        public Guid UserTokenId { get; set; }
        public string AccessTokenHash { get; set; }
        public DateTime? AccessTokenExpiresTs { get; set; }
        public string RefreshTokenIdHash { get; set; }
        public string RefreshTokenIdHashSource { get; set; }
        public DateTime? RefreshTokenExpiresTs { get; set; }
        public Guid UserId { get; set; }
        public bool IsActive { get; set; }
        public Guid CreateUser { get; set; }
        public DateTime CreateTs { get; set; }
        public Guid UpdateUser { get; set; }
        public DateTime UpdateTs { get; set; }

        public virtual User User { get; set; }
    }
}

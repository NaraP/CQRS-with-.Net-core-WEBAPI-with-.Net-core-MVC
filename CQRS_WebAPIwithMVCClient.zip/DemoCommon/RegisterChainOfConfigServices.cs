﻿using DemoCommon.Cors;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace DemoCommon
{
   public static class RegisterServices
    {
        /// <summary>
        /// RegisterChainOfConfigServices
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configuration"></param>
        public static void RegisterChainOfConfigServices(this IServiceCollection services, IConfiguration configuration)
        {
            //Add cors
            services.ConfigureCors();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DemoCommon.Dto
{
   public class UserRolesCommonDto
    {
        public Guid UserId { get; set; }
        [Required]
        public Guid RoleId { get; set; }

        public bool IsSystemRole { get; set; }

        public virtual RolesCommonDto RoleDto { get; set; }
    }
}

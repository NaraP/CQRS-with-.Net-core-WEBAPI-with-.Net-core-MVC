﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DemoCommon.Dto
{
   public class UserPriviledgesDto
    {
        public UserPriviledgesDto()
        {
            Priviledges = new List<string>();
        }
        public IList<string> Priviledges { get; set; }
    }
}

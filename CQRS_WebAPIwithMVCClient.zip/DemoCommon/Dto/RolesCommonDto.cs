﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DemoCommon.Dto
{
   public class RolesCommonDto
    {
        public Guid Roleid { get; set; }
        public string Rolename { get; set; }
        public string Roledescription { get; set; }
        public int? Canbedeleted { get; set; }
        public bool? Deleted { get; private set; }
        public DateTime? Createddate { get; set; }
        public int? Createdby { get; set; }
        public DateTime? Updateddate { get; set; }
        public int? Updateddby { get; set; }
    }
}

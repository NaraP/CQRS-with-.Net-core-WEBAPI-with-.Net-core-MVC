﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace DemoCommon.Dto
{
    public class LoggedInUserDto
    {
        public LoggedInUserDto()
        {
            Roles = new List<string>();
            Claims = new List<string>();
            Priviledges = new List<string>();
            ClaimsList = new List<string>{
                JwtRegisteredClaimNames.Jti,
                JwtRegisteredClaimNames.Iss,
                JwtRegisteredClaimNames.Iat,
                ClaimTypes.Email,
                ClaimTypes.Name,
                ClaimTypes.SerialNumber,
                ClaimTypes.UserData,
                "nbf",
                "exp",
                "aud"
            };

        }

        public Guid UserId { get; set; }

        public string UserName { get; set; }

        public string Email { get; set; }

        public bool IsSystemRole { get; set; }

        public List<string> Roles { get; set; }

        public List<string> Priviledges { get; set; }

        public List<string> Claims { get; set; }

        public List<string> ClaimsList { get; set; }
    }
}

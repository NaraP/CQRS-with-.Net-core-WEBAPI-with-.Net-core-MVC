﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DemoCommon.Exceptions
{
   public class DemoException :Exception
    {
        /// <summary>
        /// AbbRelCareException
        /// </summary>
        public DemoException()
        { }

        /// <summary>
        /// AbbRelCareException
        /// </summary>
        /// <param name="message"></param>
        public DemoException(string message)
            : base(message)
        { }

        /// <summary>
        /// AbbRelCareException
        /// </summary>
        /// <param name="message"></param>
        /// <param name="innerException"></param>
        public DemoException(string message, Exception innerException)
            : base(message, innerException)
        { }

    }
}

﻿using DemoCommon.Dto;
using DemoCommon.Helper;
using DemoCommon.IServices;
using DemoCommon.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoCommon.Services
{
    public class UserAuthService : IUserAuthService
    {
        private readonly ISecurityService _securityService;
        private readonly IOptionsSnapshot<BearerTokensOptions> _configuration;

        private readonly TestDemoContext _testDemoContext;
        private readonly IConfiguration _iconfigurations;
        private readonly IHttpContextAccessor _httpContextAccessor;

        /// <summary>
        /// UserService
        /// </summary>
        /// <param name="securityService"></param>
        /// <param name="configuration"></param>
        /// <param name="abbrcdevContext"></param>
        public UserAuthService(ISecurityService securityService, IOptionsSnapshot<BearerTokensOptions> configuration, IHttpContextAccessor httpContextAccessor,
            TestDemoContext testDemoContext, IConfiguration iconfiguration)
        {
            _securityService = securityService;
            _configuration = configuration;
            _testDemoContext = testDemoContext;
            _iconfigurations = iconfiguration;
            _httpContextAccessor = httpContextAccessor;
        }

        /// <summary>
        /// AddUserTokenAsync
        /// </summary>
        /// <param name="user"></param>
        /// <param name="refreshToken"></param>
        /// <param name="accessToken"></param>
        /// <param name="refreshTokenSource"></param>
        /// <returns></returns>
        public async Task AddUserTokenAsync(UserDto user, string refreshToken, string accessToken, string refreshTokenSource)
        {
            var now = DateTime.Now.ToUniversalTime();
            var token = new UserTokenDto
            {
                Id = Guid.NewGuid(),
                UserId = user.UserId,
                // Refresh token handles should be treated as secrets and should be stored hashed
                RefreshTokenIdHash = _securityService.GetSha256Hash(refreshToken),
                RefreshTokenIdHashSource = string.IsNullOrWhiteSpace(refreshTokenSource) ?
                                           null : _securityService.GetSha256Hash(refreshTokenSource),
                AccessTokenHash = _securityService.GetSha256Hash(accessToken),
                RefreshTokenExpiresDateTime = now.AddMinutes(_configuration.Value.RefreshTokenExpirationMinutes),
                AccessTokenExpiresDateTime = now.AddMinutes(_configuration.Value.AccessTokenExpirationMinutes),
                SerialNumber = user.SerialNumber
            };
            await AddUserTokenAsync(token);
        }

        /// <summary>
        /// AddUserTokenAsync
        /// </summary>
        /// <param name="userTokenDto"></param>
        /// <returns></returns>
        public async Task AddUserTokenAsync(UserTokenDto userTokenDto)
        {
            if (!_configuration.Value.AllowMultipleLoginsFromTheSameUser)
            {
                await InvalidateUserTokensAsync(userTokenDto.UserId);
            }
            await DeleteTokensWithSameRefreshTokenSourceAsync(userTokenDto.RefreshTokenIdHashSource);
            await _testDemoContext.UserToken.AddAsync(Mapper.CommonMapper.MapUserTokenDTOToUserToken(userTokenDto));
            await _testDemoContext.SaveChangesAsync();
        }

        /// <summary>
        /// InvalidateUserTokensAsync
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task InvalidateUserTokensAsync(Guid userId)
        {
            await _testDemoContext.UserToken.Where(x => x.UserId == userId)
                         .ForEachAsync(userToken =>
                         {
                             _testDemoContext.UserToken.Remove(userToken);
                         });
        }

        /// <summary>
        /// DeleteTokensWithSameRefreshTokenSourceAsync
        /// </summary>
        /// <param name="refreshTokenIdHashSource"></param>
        /// <returns></returns>
        public async Task DeleteTokensWithSameRefreshTokenSourceAsync(string refreshTokenIdHashSource)
        {
            if (string.IsNullOrWhiteSpace(refreshTokenIdHashSource))
            {
                return;
            }
            await _testDemoContext.UserToken.Where(t => t.RefreshTokenIdHashSource == refreshTokenIdHashSource)
                         .ForEachAsync(userToken =>
                         {
                             _testDemoContext.UserToken.Remove(userToken);
                         });
        }

        /// <summary>
        /// FindUserAsync
        /// </summary>
        /// <param name="userDto"></param>
        /// <returns></returns>
        public async Task<UserDto> FindUserAsyncOPCandPerformaceModel(UserDto userDto)
        {
            var userFromDb = GetSlat(userDto.UserName);
            var user = default(User);

            if (userFromDb != null)
            {
                bool passwordHash1 = PasswordHash.Validate(userDto.Password, userFromDb.SaltHash, userFromDb.Password);

                if (passwordHash1)
                {
                    user = await _testDemoContext.User
                                .Include(u => u.UserRole)
                                    .ThenInclude(s => s.Role)
                                .ThenInclude(s => s.RolePrivilegeSecurable)
                                 .ThenInclude(p => p.Privilege)
                                   .ThenInclude(z => z.RolePrivilegeSecurable)
                             .ThenInclude(k => k.Securable)
                            .Where(u => u.UserId.Equals(userFromDb.UserId))
                            .SingleOrDefaultAsync().ConfigureAwait(false);
                }
            }

            return user != null ? Mapper.CommonMapper.UserToUserDto(user) : null;
        }


        public async Task<UserDto> FindUserAsyncById(Guid userId)
        {
            //LDAP authentication checks

            var user = await _testDemoContext.User.SingleOrDefaultAsync(s => (s.UserId == userId) && s.IsActive.Value).ConfigureAwait(false);

            return user != null ? Mapper.CommonMapper.UserToUserDto(user) : null;
        }

        /// <summary>
        /// UpdateUserLastActivityDateAsync
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task UpdateUserLastActivityDateAsync(Guid userId)
        {

            await _testDemoContext.SaveChangesAsync().ConfigureAwait(false);
        }

        public async Task<UserDto> ResetPassword(UserDto resetUserPassword)
        {
            var user = await _testDemoContext.User.SingleOrDefaultAsync(s => (s.UserId == resetUserPassword.UserId && s.Password == resetUserPassword.EmailId) && s.IsActive.Value).ConfigureAwait(false);

            return user != null ? Mapper.CommonMapper.UserToUserDto(user) : null;
        }

        public User GetSlat(string guid)
        {
            var result = _testDemoContext.User.FirstOrDefault(slt => slt.EmailId.ToLower().Trim().Equals(guid.ToLower().Trim()));

            return result;
        }

        public async Task<UserDto> FindUserAsyncByEmailId(String userEmailId)
        {
            var user = await _testDemoContext.User.SingleOrDefaultAsync(s => (s.EmailId.Equals(userEmailId)) && s.IsActive.Value).ConfigureAwait(false);

            return user != null ? Mapper.CommonMapper.UserToUserDto(user) : null;
        }

        public async Task<UserDto> FindUserAsync(UserDto userDto)
        {
            //userDto.Password = CryptographyHelper.DecryptStringAES(userDto.Password);

            var userFromDb = GetSlat(userDto.UserName);
            var user = default(User);
            var usersCommonDto = new UserDto();
            if (userFromDb != null)
            {
                
                bool passwordHash1 = PasswordHash.Validate(userDto.Password, userFromDb.SaltHash, userFromDb.Password);
            
                if (passwordHash1)
                {
                    user = await _testDemoContext.User
                                .Include(u => u.UserRole)
                                    .ThenInclude(s => s.Role)
                                .ThenInclude(s => s.RolePrivilegeSecurable)
                                 .ThenInclude(p => p.Privilege)
                                   .ThenInclude(z => z.RolePrivilegeSecurable)
                             .ThenInclude(k => k.Securable)
                            .Where(u => u.UserId.Equals(userFromDb.UserId))
                            .SingleOrDefaultAsync().ConfigureAwait(false);
                }
            }
            if (user != null)
            {
                usersCommonDto = Mapper.CommonMapper.UserToUserDto(user);
            }
            return usersCommonDto;
        }

    }
}

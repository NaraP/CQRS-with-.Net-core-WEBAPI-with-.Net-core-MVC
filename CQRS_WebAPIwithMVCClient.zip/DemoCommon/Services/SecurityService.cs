﻿using DemoCommon.IServices;
using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace DemoCommon.Services
{
    public class SecurityService : ISecurityService
    {
        /// <summary>
        /// GetSha256Hash this method is used for the password hashing
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public string GetSha256Hash(string input)
        {
            using (var hashAlgorithm = new SHA256CryptoServiceProvider())
            {
                var byteValue = Encoding.UTF8.GetBytes(input);
                var byteHash = hashAlgorithm.ComputeHash(byteValue);
                return Convert.ToBase64String(byteHash);
            }
        }

    }
}

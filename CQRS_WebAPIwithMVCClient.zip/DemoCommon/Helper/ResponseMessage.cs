﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DemoCommon.Helper
{
    public sealed class ResponseMessage : ResponseMessageBase
    {
        /// <summary>
        /// ResponseMessage constructor
        /// </summary>
        public ResponseMessage() : base()
        {
        }

        /// <summary>
        /// ResponseMessage constructor with parameters
        /// </summary>
        /// <param name="statusCode"></param>
        /// <param name="statusDescription"></param>
        /// <param name="errorMessage"></param>
        /// <param name="returnObj"></param>
        public ResponseMessage(int statusCode, string statusDescription, string errorMessage, object returnObj) : base(statusCode, statusDescription, errorMessage, returnObj)
        {
        }
    }
}

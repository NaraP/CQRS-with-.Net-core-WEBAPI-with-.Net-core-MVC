﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DemoCommon.Extensions
{
   public static class CommonExtensions
    {
        /// <summary>
        /// Checks if the argument is null.
        /// </summary>
        public static void CheckArgumentIsNull(this object o, string name)
        {
            if (o == null)
                throw new ArgumentNullException(name);
        }
    }
}

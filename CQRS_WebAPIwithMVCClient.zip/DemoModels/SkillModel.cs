﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DemoModels
{
  public  class SkillModel
    {
        public Guid SkillId { get; set; }
   
        public string SkillName { get; set; }
    }
}
